<?php
class PayTrace extends WC_Payment_Gateway {

	function __construct() {

		// global ID
		$this->id = "geek_paytrace";

		// Show Title
		$this->method_title = esc_attr__( "PayTrace Payment Gateway", 'load-geeker-paytrace' );

		// Show Description
		$this->method_description = esc_attr__( "PayTrace ! WooCommerce Extension", 'load-geeker-paytrace' );

		// vertical tab title
		$this->title = esc_attr__( "WooCommerce PayTrace", 'load-geeker-paytrace' );

		//$this->icon = null;
		$this->icon = plugin_dir_url( __FILE__ ) . 'images/logo.png';

		$this->has_fields = true;

		// support default form with credit card
		$this->supports = array( 'default_credit_card_form', 'refunds' );

		// setting defines
		$this->init_form_fields();

		// load time variable setting
		$this->init_settings();
		
		// Turn these settings into variables we can use
		foreach ( $this->settings as $setting_key => $value ) {
			$this->$setting_key = $value;
		}
		
		$environment = ( $this->common_environment == "yes" ) ? 'TRUE' : 'FALSE';
		
		define('PAYTRACE_API_URL', 'https://api.paytrace.com');
		define('PAYTRACE_TOKEN', 'paytrace_api_token');
		define('PAYTRACE_GRANT_TYPE', 'password');

		if('TRUE' == $environment){
			define('PAYTRACE_USERNAME', $this->common_test_username);
			define('PAYTRACE_PASSWORD', $this->common_test_password);
			define('CONFIGENV', 'test');
		}else{
			define('PAYTRACE_USERNAME', $this->common_username);
			define('PAYTRACE_PASSWORD', $this->common_password);
			define('CONFIGENV', 'live');
		}
		
		// further check of SSL if you want
		add_action( 'admin_notices', array( $this,	'do_ssl_check' ) );
		
		// Save settings
		if ( is_admin() ) {
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		}		
	}

	// administration fields for common Gateway
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'			=> esc_attr__( 'Enable / Disable', 'load-geeker-paytrace' ),
				'label'			=> esc_attr__( 'Enable this payment gateway', 'load-geeker-paytrace' ),
				'type'			=> 'checkbox',
				'default'		=> 'no',
			),

			'common_environment' => array(
				'title'			=> esc_attr__( 'PayTrace Test Mode', 'load-geeker-paytrace' ),
				'label'			=> esc_attr__( 'Enable Test Mode', 'load-geeker-paytrace' ),
				'type'			=> 'checkbox',
				'description' 	=> esc_attr__( 'This is the test mode of gateway.', 'load-geeker-paytrace' ),
				'default'		=> 'no',
			),

			'title' => array(
				'title'		=> esc_attr__( 'Title', 'load-geeker-paytrace' ),
				'type'		=> 'text',
				'desc_tip'	=> esc_attr__( 'Payment Gateway Title on Checkout Form.', 'load-geeker-paytrace' ),
				'default'	=> esc_attr__( 'Credit card', 'load-geeker-paytrace' ),
			),

			'description' => array(
				'title'		=> esc_attr__( 'Description', 'load-geeker-paytrace' ),
				'type'		=> 'textarea',
				'desc_tip'	=> esc_attr__( 'Payment Gateway Description on Checkout Form.', 'load-geeker-paytrace' ),
				'default'	=> esc_attr__( 'Successfully payment through credit card.', 'load-geeker-paytrace' ),
				'css'		=> 'max-width:450px;'
			),

			'common_test_username' => array(
				'title'		=> esc_attr__( 'PayTrace Test Username', 'load-geeker-paytrace' ),
				'type'		=> 'text',
				'desc_tip'	=> esc_attr__( 'This is the PayTrace Username used for testing purpose.', 'load-geeker-paytrace' ),
			),

			'common_test_password' => array(
				'title'		=> esc_attr__( 'PayTrace Test Password', 'load-geeker-paytrace' ),
				'type'		=> 'text',
				'desc_tip'	=> esc_attr__( 'This is the PayTrace Password used for testing purpose.', 'load-geeker-paytrace' ),
			),

			'common_username' => array(
				'title'		=> esc_attr__( 'PayTrace Live Username', 'load-geeker-paytrace' ),
				'type'		=> 'text',
				'desc_tip'	=> esc_attr__( 'This is the PayTrace Username used for production purpose.', 'load-geeker-paytrace' ),
			),

			'common_password' => array(
				'title'		=> esc_attr__( 'PayTrace Live Password', 'load-geeker-paytrace' ),
				'type'		=> 'text',
				'desc_tip'	=> esc_attr__( 'This is the PayTrace Username used for production purpose.', 'load-geeker-paytrace' ),
			)
		);		
	}

	public function paytrace_api_generate_token_callback(){
		$url  = PAYTRACE_API_URL.'/oauth/token';
		$response = wp_remote_post( $url, array(
		    'method'      => 'POST',
		    'timeout'     => 45,
		    'redirection' => 5,
		    'httpversion' => '1.0',
		    'blocking'    => true,
		    'headers'     => array(
		    	'content-type' => 'application/x-www-form-urlencoded',
		    ),
		    'body'        => array(
		        'grant_type' => PAYTRACE_GRANT_TYPE,
		        'username' => PAYTRACE_USERNAME,
		        'password' => PAYTRACE_PASSWORD
		    ),
		    'cookies'     => array()
		    )
		);
		
		if ( is_wp_error( $response ) ) {
		    $error_message = $response->get_error_message();
		    echo "Something went wrong: $error_message";
		} else {
	        $body = $response['body'];
	        $expriry_time = json_decode($body); 
	        set_transient( PAYTRACE_TOKEN, $body, $expriry_time->expires_in );
		}
		return true;
	}

	public function paytrace_api_keyed_sale_transaction_callback($checkout_details = array(), $customer_details = array()){
    	$url  = PAYTRACE_API_URL.'/v1/transactions/sale/keyed';
	    
	    if ( false === ( $paytrace_token = get_transient( PAYTRACE_TOKEN ) ) ) {
	            $this->paytrace_api_generate_token_callback();
	        }

	    $paytrace_token = get_transient( PAYTRACE_TOKEN );
	    $paytrace_token_decode = json_decode($paytrace_token);
	    $access_token = $paytrace_token_decode->access_token;

	    $expiry = explode('/', $checkout_details['geek_paytrace-card-expiry']);
	    $expiry_month =  trim($expiry['0']);
	    $expiry_year = trim($expiry['1']);

	    $headers = array(
	                        'Authorization' => "Bearer {$access_token}",
	                        'Content-Type' => 'application/json; charset=utf-8'
	                    );

	    $body = array(
	    			"amount" => $customer_details->order_total,
	    			"credit_card" => array(
	    								"number" => trim($checkout_details['geek_paytrace-card-number']),
	    								//"number" => '4111111111111111',
	    								"expiration_month" => $expiry_month,
									    "expiration_year" => $expiry_year
	    							),
	    			"csc" => trim($checkout_details['geek_paytrace-card-cvc']),
	    		);

	   
		$response = wp_remote_post( $url, array(
	            'method' => 'POST',
	            'timeout' => 45,
	            'redirection' => 5,
	            'httpversion' => '1.0',
	            'blocking' => true,
	            'headers' => $headers,
	            'body' => json_encode($body),
	            'cookies' => array()
	            )
	        );
		
		if ( is_wp_error( $response ) ) {
	       $error_message = $response->get_error_message();
	       $customer_details->add_order_note( 'Error: Payment Failure. '.$error_message );
	       return false;
	    } else {
	        $response_body = $response['body'];
	        $response_body = json_decode($response_body);
	        return $response_body;
	    }
	}


	public function paytrace_api_refund_by_transactionid_callback($amount = null, $transaction_id = null){
    
	    $url  = PAYTRACE_API_URL.'/v1/transactions/refund/for_transaction';
	    
	    if ( false === ( $paytrace_token = get_transient( PAYTRACE_TOKEN ) ) ) {
	            $this->paytrace_api_generate_token_callback();
	        }

	    $paytrace_token = get_transient( PAYTRACE_TOKEN );
	    $paytrace_token_decode = json_decode($paytrace_token);
	    $access_token = $paytrace_token_decode->access_token;

	    $headers = array(
	                        'Authorization' => "Bearer {$access_token}",
	                        'Content-Type' => 'application/json; charset=utf-8'
	                    );

	    $body = array(
	    			"amount" => $amount,
	    			"transaction_id" => $transaction_id,
	    		);

	    
		$response = wp_remote_post( $url, array(
	            'method' => 'POST',
	            'timeout' => 45,
	            'redirection' => 5,
	            'httpversion' => '1.0',
	            'blocking' => true,
	            'headers' => $headers,
	            'body' => json_encode($body),
	            'cookies' => array()
	            )
	        );
		
		if ( is_wp_error( $response ) ) {
	       $error_message = $response->get_error_message();
	       return $response;
	    } else {
	        
	        $response_body = $response['body'];
	        $response_body =  json_decode($response_body);
	        return $response_body;
	        
	    }
	}

	// Response handled for payment gateway
	public function process_payment( $order_id ) {
		global $woocommerce;
    	$customer_order = new WC_Order( $order_id );
    	$checkout_data = $_REQUEST;
    	$response = $this->paytrace_api_keyed_sale_transaction_callback($checkout_data, $customer_order);
    	
    	if( isset($response->success) && isset($response->transaction_id) && 1 == $response->success){
    		$customer_order->add_order_note( esc_attr__( 'Your payment has been completed by PayTrace.', 'load-geeker-paytrace' ) );
			$customer_order->payment_complete($response->transaction_id);
			$woocommerce->cart->empty_cart();
			
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url( $customer_order ),
			);
    	}else{
    		wc_add_notice( 'Payment Failure', 'error' );
			wc_add_notice( 'Result code: '.$response->response_code, 'error' );
			$customer_order->add_order_note( 'Error: Payment Failure. Result code: '.$response->response_code );	
    	}
	}
	
	// Response handled for payment gateway
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		global $woocommerce;
		$customer_order = new WC_Order( $order_id );
		$transaction_id =  get_post_meta( $order_id, '_transaction_id', true );
		$response = $this->paytrace_api_refund_by_transactionid_callback($amount, $transaction_id);
		if($response->success == 1){
			return true;
		}
		return false;
	}


	// Validate fields
	public function validate_fields() {
		return true;
	}

	public function do_ssl_check() {
		if( $this->enabled == "yes" ) {
			if( get_option( 'woocommerce_force_ssl_checkout' ) == "no" ) {
				echo "<div class=\"error\"><p>". sprintf( "<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href=\"%s\">forcing the checkout pages to be secured.</a>", $this->method_title, admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) ."</p></div>";	
			}
		}		
	}
}