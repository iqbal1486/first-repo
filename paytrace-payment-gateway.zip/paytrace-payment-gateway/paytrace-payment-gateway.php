<?php
/*
Plugin Name: PayTrace Payment Gateway
Plugin URI: http://geekerhub.com
Description: Woocommerce payment gateway to collect payment via PayTrace API.
Version:     1.0.0
Author:      overview
Plugin URI:  https://overviewhere.com
Author URI:  https://overviewhere.com
*/
function paytrace_register_gateway( $methods ) {
	$methods[] = 'PayTrace';
	return $methods;
}

function paytrace_plugin_loaded_init() {
    //if condition use to do nothing while WooCommerce is not installed
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;
	include_once( 'PayTrace.php' );

	// class add it too WooCommerce
	add_filter( 'woocommerce_payment_gateways', 'paytrace_register_gateway' );
}
add_action( 'plugins_loaded', 'paytrace_plugin_loaded_init', 0 );

add_action( 'init', 'paytrace_load_plugin_textdomain');
function paytrace_load_plugin_textdomain() {
	$domain = 'load-geeker-paytrace';
	$mo_file = WP_LANG_DIR . '/' . $domain . '/' . $domain . '-' . get_locale() . '.mo';
	load_textdomain( $domain, $mo_file ); 
	load_plugin_textdomain( $domain, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}

// Add custom action links
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'paytrace_action_links' );
function paytrace_action_links( $links ) {
	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout' ) . '">' . __( 'Settings', 'load-geeker-paytrace' ) . '</a>',
	);
	return array_merge( $plugin_links, $links );
}